#include <mpi.h>
#include <stdio.h>
#include <string.h>
#include <complex.h>
#include <math.h>

int main( int argc, char** argv ) {

	MPI_Init(&argc, &argv);

	int np, rank;
	MPI_Comm_size(MPI_COMM_WORLD, &np);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	int x = 0;
	int y = 0;
	int A = 0;
	int B = 0;

	if (rank == 0) {
		x = 1;
		A = y;
		printf("A = %d\n", A);
	}
	else if (rank == 1) {
		y = 1;
		B = x;
		printf("B = %d\n", B);
	}

	MPI_Finalize();

	return 0;	
}
