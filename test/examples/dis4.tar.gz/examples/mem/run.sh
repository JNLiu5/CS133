mpicc -o mem mem.c
mpirun -np 2 mem
