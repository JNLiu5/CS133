mpicc -o bcast bcast.c -std=c99 -lmpi -lm -O3
mpirun -np 4 bcast

