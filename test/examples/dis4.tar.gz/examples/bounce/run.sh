mpicc -o bounce bounce.c
mpirun -np 2 bounce
