mpicc -o hello hello.c
./hello & ./hello & ./hello & ./hello
