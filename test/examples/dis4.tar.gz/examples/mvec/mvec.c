#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

#define A(i, j) A[i*n+j]

void mvec1(float *A, float *x, float *y, int n)
{
	int i, j;
#pragma omp parallel for private(j)
	for (i=0; i<n; i++) {
		y[i] = 0;
		for (j=0; j<n; j++){
			y[i] += A(i,j)*x[j];
		}
	}
}

int compute_diff(float *y, float *yans, int n)
{
	int cnt = 0;
	int i, j;
	float diff = 0.0;
	float power = 0.0;

	int error = 0;
	for (i=0; i<n; i++) {
		if (fabs(y[i] - yans[i]) > 10e-4)
			error++;
	}
	return error;
}

int main( int argc, char** argv ) {

	int pnum, pid;
	double elapsed_time;
	float *A, *x, *y, *yans;
	float *buffer;
	int n = 4096 * 4;
	int i, j, p;
	unsigned short seed[3];
	MPI_Status status;
	MPI_Request requests[16];
	MPI_Request request;

	if( argc != 1 ){
		if( argc == 2 ){
			n = atoi(argv[1]);
		}
		else{
			printf("mvec [n]\n");
			exit(0);
		}
	}

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &pnum);
	MPI_Comm_rank(MPI_COMM_WORLD, &pid);

	x = (float*)malloc( sizeof(float) * n );

	if( pid == 0 ){
		fprintf(stderr, "Starting Init...");

		A = (float*)malloc( sizeof(float) * n * n );
		y = (float*)malloc( sizeof(float) * n );
		buffer = (float*)malloc( sizeof(float) * n * n + MPI_BSEND_OVERHEAD);
		MPI_Buffer_attach(buffer, sizeof(float)*n*n + MPI_BSEND_OVERHEAD);

		seed[0] = 0; seed[1] = 1; seed[2] = 2;

		for (i=0; i<n; i++) {
			for (j=0; j<n; j++) {
				A(i,j) = (float)erand48(seed);
			}
		}
		for (j=0; j<n; j++) {
			x[j] = (float)erand48(seed);
		}
		fprintf(stderr, "Done\n");
	}
	else{
		buffer = (float*)malloc( sizeof(float)*n );
		MPI_Buffer_attach(buffer, sizeof(float)*n);
	}


	MPI_Barrier(MPI_COMM_WORLD);
	elapsed_time = -1*MPI_Wtime();
	
	float* la = (float*) malloc( sizeof(float) * n * n/pnum );
	float* lx = (float*) malloc( sizeof(float) * n );
	float* ly = (float*) malloc( sizeof(float) * n/pnum );

	if( pid == 0 ){
		// Send data to processors
		for( p = 1 ; p < pnum ; p++ )
		{
			fprintf(stderr, "pid 0 is sending matrix A to pid %d\n", p);
			//MPI_Send( &A[n*n/pnum*p], n*n/pnum, MPI_FLOAT, p, 0, MPI_COMM_WORLD);
			//MPI_Bsend( &A[n*n/pnum*p], n*n/pnum, MPI_FLOAT, p, 0, MPI_COMM_WORLD);
			MPI_Isend( &A[n*n/pnum*p], n*n/pnum, MPI_FLOAT, p, 0, MPI_COMM_WORLD, &requests[p]);
		}

		for( p = 1 ; p < pnum ; p++ )
			MPI_Wait(&requests[p], &status);

		// store it locally for processor 0
		for( i = 0 ; i < n/pnum ; i++ )
			for( j = 0 ; j < n ; j++ )
				la[i*n+j] = A[i*n+j];
		
		// send vector x
		for( p = 1 ; p < pnum ; p++ )
		{
			fprintf(stderr, "pid 0 is sending vector x to pid %d\n", p);
			//MPI_Send( x, n, MPI_FLOAT, p, 0, MPI_COMM_WORLD);
			//MPI_Bsend( x, n, MPI_FLOAT, p, 0, MPI_COMM_WORLD);
			MPI_Isend( x, n, MPI_FLOAT, p, 0, MPI_COMM_WORLD, &requests[p]);
		}
		for( j = 0 ; j < n ; j++ )
			lx[j] = x[j];

	}
	else{
		fprintf(stderr, "pid %d is waiting for matrix A from pid 0\n", pid);
		//MPI_Recv( la, n*n/pnum, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, &status);
		MPI_Irecv( la, n*n/pnum, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, &requests[0]);
		fprintf(stderr, "pid %d got matrix A\n", pid);

		fprintf(stderr, "pid %d is waiting for vector x from pid 0\n", pid);
		MPI_Recv( lx, n, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, &status);
		//MPI_Irecv( lx, n, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, &requests[1]);
		fprintf(stderr, "pid %d got vector x\n", pid);

	}
	MPI_Bcast( x, n, MPI_FLOAT, 0, MPI_COMM_WORLD);
/*
	if( pid == 0 ){
	}
	else{
		MPI_Wait(&requests[0], &status);
		MPI_Wait(&requests[1], &status);
	}
*/
	fprintf(stderr, "pid %d starts computation\n", pid);

	//computation
	for( i = 0 ; i < n/pnum ; i++ ){
		ly[i] = 0;
		for( j = 0 ; j < n ; j++ )
			//ly[i] += la[i*n+j] * lx[j];
			ly[i] += la[i*n+j] * x[j];
	}

	if( pid == 0 ){
		// Receive data from processors
		for( p = 1 ; p < pnum ; p++ )
		{
			MPI_Recv( &y[n/pnum*p], n/pnum, MPI_FLOAT, p, 0, MPI_COMM_WORLD, &status);
		}
		// store it locally for processor 0
		for( i = 0 ; i < n/pnum ; i++ )
			y[i] = ly[i];
	}
	else{
		// Send data from processors
		//MPI_Send( ly, n/pnum, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
		MPI_Bsend( ly, n/pnum, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
	}

	MPI_Barrier(MPI_COMM_WORLD);
	elapsed_time += MPI_Wtime();

	if( pid == 0 ) {
		printf("Elapsed Time : %f secs\n", elapsed_time);

		yans = (float*)malloc( sizeof(float) * n * n );
		mvec1(A, x, yans, n);
		int diff = compute_diff(y, yans, n);

    printf("Performance  : %.2f GFlops\n", 2.0*n*n/elapsed_time/1000000000 );
		printf("Result Diff  : %d\n", diff );

		free(A);
		free(x);
		free(y);
		free(yans);
	}
	free(buffer);

	MPI_Finalize();

	return 0;	
}
