#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

#define SIZE 1024

int main( int argc, char** argv ) {

	int pnum, pid;
	float *A, *B, *C;
	int n = SIZE;

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &pnum);
	MPI_Comm_rank(MPI_COMM_WORLD, &pid);

	if( pid == 0 ){
		fprintf(stderr, "Intializing vector : %d\n", n);

		A = (float*)malloc( sizeof(float) * n);
		B = (float*)malloc( sizeof(float) * n);
		C = (float*)malloc( sizeof(float) * n);

		srand(0);

		for (int i = 0; i < n; i++) {
			A[i] = (float) rand();
			B[i] = (float) rand();
		}
	}

	MPI_Barrier(MPI_COMM_WORLD);

	// Compute
	MPI_Status status;
	int part = n / pnum;

//	int bufferSize = sizeof(float) * n + MPI_BSEND_OVERHEAD;
//	float *buff = (float *)malloc(bufferSize);
	float *locA = (float *)malloc(sizeof(float) * part);
	float *locB = (float *)malloc(sizeof(float) * part);
	float *locC = (float *)malloc(sizeof(float) * part);

	if (pid == 0) { // Thread 0 send a part of vectors
		for (int i = 1; i < pnum; i++) {
			fprintf(stderr, "pid 0 is sending vectors to pid %d\n", i);
			MPI_Send(&(A[i * part]), part, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
			MPI_Send(&(B[i * part]), part, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
		}
		for (int i = 0; i < part; i++)
			locA[i] = A[i];
		for (int i = 0; i < part; i++)
			locB[i] = B[i];
	}
	else {	// Other thread receives a part of vectors
		MPI_Recv(locA, part, MPI_FLOAT, 0, 0, MPI_COMM_WORLD, &status);
		fprintf(stderr, "pid %d received vectors from pid 0\n", pid);
	}
	MPI_Barrier(MPI_COMM_WORLD);

	// Vector add
	for (int i = 0; i < part; i++)
		locC[i] = locA[i] + locB[i];

	if (pid == 0) { // Thread 0 receives the result
		for (int i = 1; i < pnum; i++) {
			fprintf(stderr, "pid 0 is receiving from pid %d\n", i);
			MPI_Recv(&(C[i * part]), part, MPI_FLOAT, i, 2, MPI_COMM_WORLD, &status);
		}
		for (int i = 0; i < part; i++)
			C[i] = locC[i];
	}
	else { // Others send the result
		MPI_Send(locC, part, MPI_FLOAT, 0, 2, MPI_COMM_WORLD);
		fprintf(stderr, "pid %d sent the result\n", pid);
	}

	free(locA);
	free(locB);
	free(locC);
	// computation done	

	MPI_Barrier(MPI_COMM_WORLD);

	if (pid == 0)
		fprintf(stderr, "All done!\n");

	if( pid == 0 ) {
		free(A);
		free(B);
		free(C);
	}

	MPI_Finalize();

	return 0;	
}
