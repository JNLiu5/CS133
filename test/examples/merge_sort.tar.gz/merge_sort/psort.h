int* getRandomArray(int size, int min, int max);
void displayArray(int *arr, int size);
int* dupArray(int *arr, int size);
int diffArrays(int *arr1, int* arr2, int size);
int getRank(int* arr, int left, int right, int item);
