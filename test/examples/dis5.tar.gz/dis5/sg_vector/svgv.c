#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include <string.h>

#define SIZE 16

void print_array(int *arr, int size){
   for(int i=0;i<size;i++){
      printf("%d ", arr[i]);
   }
   printf("\n");
}

void compute_squares_unsafe(int *arr){
   int pnum, pid;

   MPI_Comm_rank(MPI_COMM_WORLD, &pid);
   MPI_Comm_size(MPI_COMM_WORLD, &pnum);

   // Size of each process's data 
   // Unsafe if division yields a remainder
   int lsize = SIZE / pnum;
   int *larr = (int *)malloc(sizeof(int) * lsize);
   
   MPI_Scatter(arr, lsize, MPI_INT, larr, lsize, MPI_INT, 0, MPI_COMM_WORLD);

   if(pid == 0){
      for(int i=0;i<lsize;i++){
         larr[i] = arr[i];
      }
   }

   for(int i=0;i<lsize;i++){
      larr[i] *= larr[i];
   }

   MPI_Gather(larr, lsize, MPI_INT, arr, lsize, MPI_INT, 0, MPI_COMM_WORLD);
}

void compute_squares_safe(int *arr){
   int pnum, pid;

   MPI_Comm_rank(MPI_COMM_WORLD, &pid);
   MPI_Comm_size(MPI_COMM_WORLD, &pnum);

   // Size of each process's data
   // Safe even if division yields a remainder
   int lsize = SIZE / pnum;
   int count = SIZE;
   int displ = 0; 
   int *lsizev = (int *)malloc(sizeof(int) * pnum);
   int *displv = (int *)malloc(sizeof(int) * pnum);

   for(int p=0;p<pnum;p++){
      if(count >= lsize){
         lsizev[p] = lsize;
         displv[p] = displ;
         count -= lsize;
         displ += lsize;
      }
      else{
         lsizev[p] = count;
         displv[p] = displ;
         displ += count;
         count = 0;
      }
   }

   lsizev[pnum-1] += count;
   
   if(pid == 0){
      print_array(lsizev, pnum);
      print_array(displv, pnum);
   }

   int *larr = (int *)malloc(sizeof(int) * lsizev[pid]);
   
   MPI_Scatterv(arr, lsizev, displv, MPI_INT, larr, lsizev[pid], MPI_INT, 0, MPI_COMM_WORLD);

   if(pid == 0){
      for(int i=0;i<lsizev[pid];i++){
         larr[i] = arr[i];
      }
   }

   for(int i=0;i<lsizev[pid];i++){
      larr[i] *= larr[i];
   }

   MPI_Gatherv(larr, lsizev[pid], MPI_INT, arr, lsizev, displv, MPI_INT, 0, MPI_COMM_WORLD);
}

int main( int argc, char** argv ) {
   int diff;
   int pnum, pid;
   int *arr1, *arr2, *arr3;

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &pnum);
	MPI_Comm_rank(MPI_COMM_WORLD, &pid);

	if(pid == 0){
      arr1 = (int *)malloc(sizeof(int) * SIZE);
      arr2 = (int *)malloc(sizeof(int) * SIZE);
      arr3 = (int *)malloc(sizeof(int) * SIZE);

      for(int i=0;i<SIZE;i++){
         arr1[i] = i;
      }

      memcpy(arr2, arr1, sizeof(float) * SIZE);
      memcpy(arr3, arr1, sizeof(float) * SIZE);
	}
   
   compute_squares_unsafe(arr1);
   compute_squares_safe(arr2);
   
	MPI_Barrier(MPI_COMM_WORLD);
	
   if(pid == 0){
      for(int i=0;i<SIZE;i++){
         arr3[i] *= arr3[i];
      }
      printf("Unsafe    : ");
      print_array(arr1, SIZE); 
      printf("Safe      : ");
      print_array(arr2, SIZE); 
      printf("Correct   : ");
      print_array(arr3, SIZE);
   }
      
	MPI_Finalize();

	return 0;	
}
