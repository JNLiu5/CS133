#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

float vecadd_mpi(float *A, float *B, int n)
{
   int pnum, pid;
   MPI_Comm_rank(MPI_COMM_WORLD, &pid);
   MPI_Comm_size(MPI_COMM_WORLD, &pnum);

   int data_size = n / pnum; 
   float *A_local;
   float *B_local;
   A_local = (float*)malloc(sizeof(float) * data_size);
   B_local = (float*)malloc(sizeof(float) * data_size);
   
   int i;
   MPI_Scatter(A, data_size, MPI_FLOAT, A_local, data_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
   MPI_Scatter(B, data_size, MPI_FLOAT, B_local, data_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
   if (pid == 0){
      for (i = 0; i < data_size; i++) {
         A_local[i] = A[i];
         B_local[i] = B[i];
      }
   }

   float local_sum = 0;
//   for (int i = 0; i < data_size; i++) {
//      for (int k = 0; k < n; k++) {
//         A_local[i] *= A_local[i] * 3.14;
//      }
//   }
   for (i = 0; i < data_size; i++) {
      local_sum += A_local[i] * B_local[i];  
   }

   float global_sum;
 
   MPI_Reduce(&local_sum, &global_sum, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
   free(A_local);
   return global_sum;
}

float vecadd_mpi2(float *A, float *B, int n)
{
   int pnum, pid;
   MPI_Comm_rank(MPI_COMM_WORLD, &pid);
   MPI_Comm_size(MPI_COMM_WORLD, &pnum);

   int data_size = n / pnum; 
   float *A_local;
   float *B_local;
   A_local = (float*)malloc(sizeof(float) * data_size);
   B_local = (float*)malloc(sizeof(float) * data_size);
   
   int i;
   MPI_Scatter(A, data_size, MPI_FLOAT, A_local, data_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
   MPI_Scatter(B, data_size, MPI_FLOAT, B_local, data_size, MPI_FLOAT, 0, MPI_COMM_WORLD);
   if (pid == 0){
      for (i = 0; i < data_size; i++) {
         A_local[i] = A[i];
         B_local[i] = B[i];
      }
   }

   float local_sum = 0;
//   for (int i = 0; i < data_size; i++) {
//      for (int k = 0; k < n; k++) {
//         A_local[i] *= A_local[i] * 3.14;
//      }
//   }
   for (i = 0; i < data_size; i++) {
      local_sum += A_local[i] * B_local[i];  
   }

   float global_sum;
   if (pid == 0){
      global_sum = local_sum;
      float local_data;
      for (i = 1; i < pnum; i++) {
         MPI_Recv(&local_data, 1, MPI_FLOAT, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
         global_sum += local_data;
      }
   } else {
      MPI_Send(&local_sum, 1, MPI_FLOAT, 0, 0, MPI_COMM_WORLD);
   }
 
   //MPI_Reduce(&local_sum, &global_sum, 1, MPI_FLOAT, MPI_SUM, 0, MPI_COMM_WORLD);
   

   free(A_local);
   return global_sum;
}


float vecadd_omp(float *A, float *B, int n)
{
   float ret = 0;
//#pragma omp parallel for
//   for (int i = 0; i < n; i++) {
//      for (int k = 0; k < n; k++) {
//         A[i] *= A[i] * 3.14;
//      }
//   }
   int i;
#pragma omp parallel for reduction(+ : ret)
   for (i = 0; i < n; i++) {
      ret += A[i] * B[i];
   }
   return ret;
}

float vecadd(float *A, float *B, int n)
{
   float ret = 0;
//   for (int i = 0; i < n; i++) {
//      for (int k = 0; k < n; k++) {
//         A[i] *= A[i] * 3.14;
//      }
//   }
   int i;
   for (i = 0; i < n; i++) {
      ret += A[i] * B[i];
   }
   return ret;
}

int compute_diff(float sum, float sum_gold)
{
   int cnt = 0;   
   //printf("sum_gold: %f\n", sum_gold);
   //printf("sum: %f\n", sum);
	if (fabs(sum - sum_gold) > 10e-4)
		cnt++;
	return cnt;
}

double time1 = 0;

int main( int argc, char** argv ) {
   float *A, *B, sum, sum_omp, sum_mpi;
   int diff;
   int pnum, pid;
   int n = 1024;

	unsigned short seed[3];

	if( argc != 1 ){
		if( argc == 2 ){
			n = atoi(argv[1]);
		}
		else{
			printf("mmul [n]\n");
			exit(0);
		}
	}

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &pnum);
	MPI_Comm_rank(MPI_COMM_WORLD, &pid);

   int i;
	if( pid == 0 ){
		//printf("Intializing matrix size : %d x %d x %d\n", n, n, n);
		A = (float*)malloc( sizeof(float) * n );
		B = (float*)malloc( sizeof(float) * n );
		seed[0] = 0; seed[1] = 1; seed[2] = 2;

      for (i = 0; i < n; i++){
         A[i] = erand48(seed);
         B[i] = erand48(seed);
         //printf("A: %f B: %f\n", A[i], B[i]);
      }
	}

	MPI_Barrier(MPI_COMM_WORLD);
	
	//Please modify the content of this function
//   sum_mpi = vecadd_mpi(A, B, n);
//   sum_mpi = vecadd_mpi2(A, B, n);

	MPI_Barrier(MPI_COMM_WORLD);

	if( pid == 0 ) {
      sum = vecadd(A, B, n);
//		diff = compute_diff(sum_mpi, sum);
//		printf("Result Diff (MPI): %d\n", diff);
      
      sum_omp = vecadd_omp(A, B, n);
      diff = compute_diff(sum_omp, sum);
      printf("Result Diff (OMP): %d\n", diff);

		free(A);
		free(B);
	}

	MPI_Finalize();

	return 0;	
}
