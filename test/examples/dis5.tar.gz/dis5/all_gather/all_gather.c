#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <string.h>

/*
   ! This program shows how to use MPI_Allgather
   ! Each process creates a cell
   ! Next an all gather distributes data everywhere
   */

int numnodes, myid, mpi_err;

void init_it(int  *argc, char ***argv) {
   mpi_err = MPI_Init(argc,argv);
   mpi_err = MPI_Comm_size( MPI_COMM_WORLD, &numnodes );
   mpi_err = MPI_Comm_rank(MPI_COMM_WORLD, &myid);
}

int main(int argc,char *argv[]){
   int *myray,*send_ray,*back_ray;
   int count;
   int size,mysize,i,k,j,total;


   init_it(&argc,&argv);

   // Create a receive buffer
   int *arr = (int *)malloc(sizeof(int) * numnodes);
   memset(arr, 0, sizeof(int) * numnodes);


   arr[myid] = myid;
   
   // All gather and print
   MPI_Allgather(&arr[myid], 1, MPI_INT, arr, 1, MPI_INT, MPI_COMM_WORLD);
   
   printf("Proc %d has : ", myid);
   for(int i=0;i<numnodes;i++){
      printf("%d ", arr[i]);
   }
   printf("\n");

   MPI_Finalize();
}
