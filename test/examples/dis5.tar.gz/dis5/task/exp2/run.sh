rm -rf a.out
gcc -std=c99 -D_BSD_SOURCE main.c -fopenmp -O3
./a.out
