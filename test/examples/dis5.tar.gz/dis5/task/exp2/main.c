#include <stdio.h>
#include <omp.h>

#define CUTOFF 64
#define SIZE 1000000

float sum(float *a, int n) {
	if (n == 0)
		return 0;
	else if (n == 1)
		return *a;

	int half = n / 2;
	return sum(a, half) + sum(a + half, n - half);
}

float psum(float *a, int n) {
//	if (n == 0)
//		return 0;
//	else if (n == 1)
//		return 1;
	if (n <= CUTOFF)
		return sum(a, n);

	int half = n / 2;
	float x, y;
	#pragma omp parallel
	#pragma omp single nowait
	{
		#pragma omp task
		x = sum(a, half);
		#pragma omp task
		y = sum(a + half, n - half);
		#pragma omp taskwait
		x += y;
	}
	return x;
}

int main(int argc, char** argv) {
	
	int tnum = 16;
	omp_set_num_threads(tnum);
	
	float a[SIZE];
	for (int i = 0; i < SIZE; i++) {
		a[i] = i;
	}

	double t1 = omp_get_wtime();
	float res = sum(a, SIZE);
	printf("res: %f\n", res);
	double t2 = omp_get_wtime();

	res = psum(a, SIZE);
	printf("res: %f\n", res);
	double t3 = omp_get_wtime();
	printf("loop1: %.16lf\n", t2 - t1);
	printf("loop2: %.16lf\n", t3 - t2);

	return 0;
}
	
