export OPENCL_ROOT=/opt/intel/opencl-1.2-3.2.1.16712
export LD_LIBRARY_PATH=$OPENCL_ROOT/lib64:$LD_LIBRARY_PATH
export PATH=/usr/local/cs/bin:$PATH
export PATH=$OPENCL_ROOT/bin:$PATH
